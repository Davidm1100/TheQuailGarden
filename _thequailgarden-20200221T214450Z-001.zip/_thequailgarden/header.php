
<!DOCTYPE html>
<html>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">



<!-- Header-->

<head>
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/css?family=Cinzel&display=swap" rel="stylesheet">
    <title>The Quail Garden - Home</title>
</head>
<body>

  
    


    <!--Header-->
      <!--Navigation-->
      <div class="flex-container-header">
        <div class="logo">
              
                  <img src="img/Quail garden logo transparent.png" height="100px" width="100px" href="index.html" alt="The quail garden logo">
              
              
         <h1>The Quail Garden</h1></div>
         
        <div><ul class="navbar">
                  <li><a href="index.html">Home</a></li>
                  <li><a href="about.html">About</a></li>
                  <li><a href="our_eggs.html">Eggs</a></li>
                  <li><a href="recipes.html">Recipes</a></li>
                  <li><a href="news.html">News</a></li>
                  <li><a href="buy.html">Buy</a></li>
      
          </ul></div>  
      </div>
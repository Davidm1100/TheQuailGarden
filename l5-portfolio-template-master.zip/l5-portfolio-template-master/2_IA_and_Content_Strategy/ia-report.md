# Information Architecture Report

## Cart sort

### Introduction

Illustrated account of your process.

*Insert images/illustrations using `<img>` including photographic evidence of the testing sessions*.

### List of the card elements

* oranges
* bananas
* etc.

### Cart sort results

Illustrated summary of your findings.

---

## Tree testing

### Introduction

Illustrated account of your process.

### Illustration of the architecture tested

Show the architecture you are tree testing.

### Tree testing results

Illustrated summary of your findings.

---

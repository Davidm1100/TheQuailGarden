# The Guide

Use this folder to host/build your website.
Place your index.html on the root of this folder.
Create sub-folders for media, css etc. 
# Internationalisation

<!-- edit as required -->

## Language One

<img src="sp5-media/macos-safari.jpg" alt="" width="1000">

### Notes
Provide a description of any issues. If the issue has to be corrected add another screenshot to show the fix.

---

## Language Two

<img src="sp5-media/macos-safari.jpg" alt="" width="1000">

### Notes
Provide a description of any issues. If the issue has to be corrected add another screenshot to show the fix.

---

## Language Three

<img src="sp5-media/macos-safari.jpg" alt="" width="1000">

### Notes
Provide a description of any issues. If the issue has to be corrected add another screenshot to show the fix.

---

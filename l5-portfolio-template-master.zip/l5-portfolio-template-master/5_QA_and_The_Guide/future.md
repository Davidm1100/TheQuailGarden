# Future developments

<!--
A single team statement on possible ways the site could be further developed for the client in the future.

250 words (+/- 10%)

**Do not suggest elements that could have/should have been implemented during the project (if the team had worked better)**.
-->




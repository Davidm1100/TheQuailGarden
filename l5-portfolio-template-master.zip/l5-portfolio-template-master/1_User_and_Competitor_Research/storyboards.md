# Storyboards

Add your three storyboards.

*Tutors will download the image to view the full size persona*.

## Storyboard One

<img src="sp1-media/storyboard.png" alt="Storyboard One" width="1000">

### Name of persona in this storyboard
Provide a description and explain how this storyboard relates to the persona and your user research.

---

## Storyboard Two

<img src="sp1-media/storyboard.png" alt="Storyboard Two" width="1000">

### Name of persona in this storyboard
Provide a description and explain how this storyboard relates to the persona and your user research.

---

## Storyboard Three

<img src="sp1-media/storyboard.png" alt="Storyboard Three" width="1000">

### Name of persona in this storyboard
Provide a description and explain how this storyboard relates to the persona and your user research.

---

# Ideation Report

300 Word max

Describe and illustrate your ideation process. Describe the techniques use and report on the output/results.

Has it helped you define you project? Explore a variety of ideas in a short time? Get ann agreement on the topic of your guide? Investigate possibilities?

Put your media in the `sp1-media` folder.

Embed the images in the markdown file using either of these methods.

<img src="sp1-media/octocat.png" alt="Octocat" title="something">

```
<img src="sp1-media/octocat.png" alt="Octocat" title="something">
```

![Alt text](sp1-media/octocat.png?raw=true "Title")

```
![Alt text](sp1-media/octocat.png?raw=true "Title")
```
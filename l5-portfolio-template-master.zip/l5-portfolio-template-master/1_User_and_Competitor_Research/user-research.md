# User Research

## Summary

Provide summary (300 word max) of your findings.

---

## Profiles

- Name

- Age

- Occupation

- Description or quote

- Likes

- Dislikes

- Needs and goals

---

<!--This can be deleted prior to submission -->

Repeat the above profiles as needed. Each team member should add 2 or 3 to ensure you get a wide range of opinion.

*Some teams have also undertaken quick surveys among friends to get some instant feedback on the type of guide you intend to create*.
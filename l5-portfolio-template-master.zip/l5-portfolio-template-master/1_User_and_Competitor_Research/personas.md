# Personas

Add your three personas.

*Tutors will download the image to view the full size persona*.

<!-- edit as required -->

## Persona One

<img src="sp1-media/persona.png" alt="Persona One" width="1000">

### Name of persona
Provide a description and explain how this persona was derived from your user research.

---

## Persona Two

<img src="sp1-media/persona.png" alt="Persona Two" width="1000">

### Name of persona
Provide a description and explain how this persona was derived from your user research.

---

## Persona Three

<img src="sp1-media/persona.png" alt="Persona Three" width="1000">

### Name of persona
Provide a description and explain how this persona was derived from your user research.
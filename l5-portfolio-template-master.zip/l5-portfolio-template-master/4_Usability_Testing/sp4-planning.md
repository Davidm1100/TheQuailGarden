# SP4 Planning

## Documents

### SP4 planning document
* author(s) -
* status - 
* actions -


### Test script
* author(s) -
* status - 
* actions -


### Consent form
* author(s) -
* status - 
* actions -


### Usability testing report *
* author(s) -
* status - 
* actions -

`*` *The report comes after the test session and any further testing. People can still be assigned responsibility and start planning*.

### Notes

**Author(s)** - name - who is responsible for this document?

**Status** - this will be `draft`, change to final when complete.

**Actions** - Your to do list. Especially add notes from meetings with tutors, noting our feedback and advice.

# CONSENT FORM

## Usability testing

The team is carrying out usability testing on our coursework as part a web development assignment. Your co-operation is appreciated, as the exercise is invalid without user input.

Team ID: 

Please read the following. If you give your consent, please sign below.

1. I confirm that I am giving consent to being recorded for the student usability testing session.
2. I confirm that I have read and understand the information above.
3. I consent to the use of my images and words for said project.
4. I understand that my participation is voluntary and that I am free to withdraw at any time.

Name:

Date:

Signature of participant:
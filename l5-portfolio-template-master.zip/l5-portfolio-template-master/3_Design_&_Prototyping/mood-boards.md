# Moodboards

Add a moodboard for each team member plus a final team moodboard.

*Tutors will download the image to view the full size persona*.

<!-- edit as required -->

## Moodboard One

<img src="sp3-media/moodboard.png" alt="Team Member One" width="1000">

### Name of team member
Explain how your personal influences and inspirations for this moodboard.

---

## Moodboard Two

<img src="sp3-media/moodboard.png" alt="Team Member One" width="1000">

### Name of team member
Explain how your personal influences and inspirations for this moodboard.

---

## Moodboard Three

<img src="sp3-media/moodboard.png" alt="Team Member One" width="1000">

### Name of team member
Explain how your personal influences and inspirations for this moodboard.

---

## Moodboard Four

<img src="sp3-media/moodboard.png" alt="Team Member One" width="1000">

### Name of team member
Explain how your personal influences and inspirations for this moodboard.

---

## Moodboard Five

<img src="sp3-media/moodboard.png" alt="Team Member One" width="1000">

### Name of team member
Explain how your personal influences and inspirations for this moodboard.

---

## Team Moodboard

<img src="sp3-media/moodboard.png" alt="Team Member One" width="1000">

### Name of team member
Explain how you combined your influences and inspirations to create a group vision through this moodboard.

---

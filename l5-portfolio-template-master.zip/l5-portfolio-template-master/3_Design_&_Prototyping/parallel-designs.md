# Parallel Design Report

<!-- edit as required -->

Add each team members designs plus a final design from the team that will reflect the site you intend to build.

*Tutors will download the image to view the full size persona*.

## Design One

<img src="sp3-media/designs.png" alt="Team Member One" width="1000">

### Name of team member
Provide a short (200 words) insight into your design thinking.

---

## Design Two

<img src="sp3-media/designs.png" alt="Team Member One" width="1000">

### Name of team member
Provide a short (200 words) insight into your design thinking.

---

## Design Three

<img src="sp3-media/designs.png" alt="Team Member One" width="1000">

### Name of team member
Provide a short (200 words) insight into your design thinking.

---

## Design Four

<img src="sp3-media/designs.png" alt="Team Member One" width="1000">

### Name of team member
Provide a short (200 words) insight into your design thinking.

---

## Design Five

<img src="sp3-media/designs.png" alt="Team Member One" width="1000">

### Name of team member
Provide a short (200 words) insight into your design thinking.

---

## Team Design

<img src="sp3-media/designs.png" alt="Team Member One" width="1000">

### Final design 
Provide a short (300 words) insight into your design thinking for the final design. What elements of each of the team designs has influenced this final design (if any).

> **Note:** If the design changes again before Submission Point 5, you can add any iterations below. At the very least you need to explain if the above final design does not reflect the site submitted.

---
